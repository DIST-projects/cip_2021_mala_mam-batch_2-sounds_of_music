from django.shortcuts import render
from django.http import HttpResponse
import requests
import sys 
from subprocess import run,PIPE
from django.core.files.storage import FileSystemStorage
from PIL import Image
from soundsofmusic.models import People
# Create your views here.

def home(request):
    return render(request, 'home.html')

def lessons(request):
    return render(request, 'lessons.html')

def blesson1(request):
    return render(request, 'bass\lessons1.html')

def blessons2(request):
    return render(request, 'bass\lessons2.html')

def capture(request):
    return render(request, 'capture.html')

def progress(request):
    return render(request, 'progress.html')

def rewards(request):
    return render(request, 'rewards.html')

def login(request):
    return render(request, 'login.html')

def signup(request):
    return render(request, 'signup.html')

def listen(request):
    return render(request, 'listen.html')

def blesson1(request):
    return render(request, 'bass\lesson1.html')

def signup_good(request):
    if request.method=="POST":
        #print("This works !")
        email = request.POST['email']
        uname = request.POST['uname']
        password = request.POST['password']
        #print(email, uname, password)
        ins = People(email=email, uname=uname, password=password)
        ins.save()
        print("data has been written to the db")
    return render(request, 'signup_good.html')

def output(request):
    return render(request, 'output.html')

def external(request):
    inp = request.POST.get("instrument")
    image=request.FILES['image']
    print("image is ",image)
    fs=FileSystemStorage()
    filename=fs.save(image.name,image)
    fileurl=fs.open(filename)
    templateurl=fs.url(filename)
    print("file raw url",filename)
    print("file full url", fileurl)
    print("template url",templateurl)

   # templateurl = 'static\hero-bg.png'
    outurl = 'static\media\output\9_with_pitch.png'

    image=run([sys.executable,'C:\\cip\\music\\main.py',str(fileurl), inp],shell=False, stdout=PIPE)
    print(image)
    return render(request, 'capture.html', {'raw_url':templateurl, 'out_url':outurl, 'edit_url':image.stdout.decode()})