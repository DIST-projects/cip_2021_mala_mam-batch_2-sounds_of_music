from django.contrib import admin
from soundsofmusic.models import People

# Register your models here.
admin.site.register(People)