from django.db import models

# Create your models here.
class People(models.Model):
    email = models.EmailField()
    uname = models.CharField(max_length=20)
    password = models.CharField(max_length=20)
